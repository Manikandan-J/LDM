package com.mentorondemand.repo;

import org.springframework.data.repository.CrudRepository;

import com.mentorondemand.model.ProposalRequest;

public interface ProposalRequestRepository extends CrudRepository<ProposalRequest, Long> {

}

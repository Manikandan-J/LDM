package com.mentorondemand.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentorondemand.model.Login;
import com.mentorondemand.repo.LoginRepository;

@Service
public class LoginService {
	
	@Autowired
	private LoginRepository loginRepo;

	public List<Login> getAllCredentials() {
		// TODO Auto-generated method stub
		List<Login> credentials = new ArrayList<>();
		loginRepo.findAll().forEach(credentials::add);

		return credentials;
	}
	

}

import { Component, OnInit } from '@angular/core';
import { Login } from '../model/login';
import { LoginService } from '../service/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  // login: Login = new Login();
  
  // constructor(private loginservice: LoginService ) { }

  // ngOnInit() {
  // }
  // sendLoginData() {
  //   this.loginservice.sendLoginData(this.login)
  //     .subscribe(data => console.log(data), error => console.log(error));
  //   this.login = new Login();
    
  // }

  // onSubmit() {
  //   console.log(this.login.email+" and Password:"+this.login.password);
  //   this.sendLoginData();
    
  
  // }
  // check()
  // {
    
  // }
  email: String;
  password: String;
  invalidLogin: boolean = false;
  login: Login[];
  
  constructor(private router: Router, private loginService: LoginService) { }

  ngOnInit() {
    this.loginService.getCredentials().subscribe(response => this.login = response, error => alert(`${error.message}\nWaiting for response from server`));
  

  }

  checkLogin() {
    for (let i = 0; i < this.login.length; i++) {
      if (this.login[i].email === this.email && this.login[i].password === this.password) {
          if(this.login[i].role==="admin")
          {
        this.router.navigate(['Admin']);
          }
          if(this.login[i].role === "mentor")
          {
            this.router.navigate(['Mentor']);
          }
          if(this.login[i].role === "user")
          {
            this.router.navigate(['User']);
          }
          this.invalidLogin = false;
        // localStorage.setItem("usersId", this.login[i].email.toString());
      } else {
        this.invalidLogin = true;
      }
    }

  }

  onSubmit() {

    console.log(this.email);
    this.checkLogin();
    
  }
 
}
